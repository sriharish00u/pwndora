# PWNDORA — Vulnerability Chain Lab

Multi-stage cybersecurity training platform. Exploit a realistic web app, capture flags, generate compliance reports.

## Stack

- **Frontend:** React 19, Tailwind CSS 4, Vite, Lucide Icons
- **Backend:** Express, Vite dev server
- **Database:** MongoDB 7 (native driver, no Mongoose)
- **Auth:** bcrypt password hashing, HTTP-only session cookies
- **Optional:** Gemini AI co-pilot

## Quick Start

```bash
# install
npm install

# configure
cp .env.example .env
# edit .env — set MONGODB_URI and SESSION_SECRET

# seed database (creates users + sessions collections + sample user)
npm run db-add

# run
npm run dev
```

Open `http://localhost:3000`. Login with `test@pwndora` / `test@123`.

## Docker

```bash
docker compose up --build -d
```

Runs app + MongoDB in containers. Data persists in Docker volumes.

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `MONGODB_URI` | Yes | `mongodb://localhost:27017/pwndora` | MongoDB connection string |
| `SESSION_SECRET` | Yes | *(dev random)* | Secret for session signing |
| `ARTIFACT_SECRET` | Yes | *(dev random)* | HMAC secret for stage artifact tokens |
| `GEMINI_API_KEY` | No | — | Enables AI co-pilot and report generation |

## Attack Stages

| # | Name | Vulnerability | OWASP | CWE | CVSS |
|---|---|---|---|---|---|
| 1 | SQL Injection | Authentication bypass via unsanitized input | A03:2021 Injection | CWE-89 | 8.1 |
| 2 | Command Injection | Blind OS command injection | A03:2021 Injection | CWE-78 | 9.8 |
| 3 | Server-Side Request Forgery | Internal network pivoting | A10:2021 SSRF | CWE-918 | 7.5 |
| 4 | Broken Access Control | JWT forgery + privilege escalation | A01:2021 Broken Access Control | CWE-269 | 8.8 |

Each stage has 3 progressive hints with escalating score penalties (-10 / -20 / -30).

## Features

- **Authentication** — Register/login with bcrypt-hashed passwords, HTTP-only cookies
- **Per-user sessions** — MongoDB-backed, isolated per operator
- **Progressive hint system** — 3 hints per stage, revealed sequentially, score penalties
- **Stage artifact tokens** — HMAC-signed tokens gate sequential progression
- **OWASP/CVSS/CWE/MITRE metrics** — Displayed in stage cards, report, and code review
- **Defensive code review** — Review vulnerable code, suggest fixes, earn bonus points
- **AI co-pilot** — Optional Gemini-powered hints (toggle in settings)
- **Compliance report** — PDF-ready Pentest report with executive summary, findings, CVSS
- **Leaderboard** — Global score ranking across all operators
- **Print/PDF export** — Print-optimized CSS for report export
- **Reset lab** — Wipe progression and start fresh

## npm Scripts

| Command | Description |
|---|---|
| `npm run dev` | Start dev server (Vite + Express) |
| `npm run build` | Production build |
| `npm run start` | Run production build |
| `npm run db-add` | Seed database with schema, indexes, and sample user |
| `npm run lint` | TypeScript type check |

## Project Structure

```
pwndora-lab/
├── server.ts              # Express API, auth, session management, attack routes
├── src/
│   ├── App.tsx            # Root shell, auth UI, tab routing
│   ├── types.ts           # TypeScript interfaces (Session, Stage, User, Report)
│   ├── lib/
│   │   └── mongo.ts       # MongoDB client singleton
│   └── components/
│       ├── Dashboard.tsx  # Stage cards, score, settings
│       ├── Playground.tsx # Attack input, hint system, hacker logs
│       ├── CodeReview.tsx # Defensive code review + OWASP metrics
│       ├── ReportViewer.tsx # Compliance report display + PDF export
│       └── Leaderboard.tsx # Global rankings
├── scripts/
│   └── db-add.ts          # Database seeder (users, sessions, indexes)
├── Dockerfile             # Multi-stage production build
├── docker-compose.yml     # App + MongoDB containers
└── .env.example           # Environment template
```
